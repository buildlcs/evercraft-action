package dev.dyslexic.cinematic.client;

import dev.dyslexic.cinematic.Cinematic;
import java.lang.reflect.Method;
import net.minecraft.client.resources.model.geometry.BakedQuad;

/**
 * Tells Sodium that a sprite is in use. Sodium (and mods built like it) only advances the animation of sprites it has
 * seen drawn this frame; the scene replays item quads through its own buffers, so without this call an animated
 * item texture can stay on one frame. Everything is looked up by reflection: with no Sodium, or an API that
 * looks different, this does nothing and the first failure switches it off for good.
 */
final class SpriteActivity {
    private SpriteActivity() {}

    private static boolean ready, off;
    private static Method spriteOf;      // BakedQuad.MaterialInfo#sprite()
    private static Object util;          // SpriteUtil.INSTANCE, or null for a static markSpriteActive
    private static Method mark;          // SpriteUtil#markSpriteActive(TextureAtlasSprite)

    static void mark(BakedQuad quad) {
        if (off) {
            return;
        }
        try {
            if (!ready) {
                init(quad);
            }
            if (off) {
                return;
            }
            Object sprite = spriteOf.invoke(quad.materialInfo());
            if (sprite != null) {
                mark.invoke(util, sprite);
            }
        } catch (ReflectiveOperationException | RuntimeException | LinkageError e) {
            off = true;
            Cinematic.LOGGER.debug("[Cinematic] Sprite activity hint disabled", e);
        }
    }

    private static void init(BakedQuad quad) {
        ready = true;
        try {
            Class<?> api = Class.forName("net.caffeinemc.mods.sodium.api.texture.SpriteUtil");
            Method accessor = quad.materialInfo().getClass().getMethod("sprite");
            accessor.setAccessible(true);
            Method target = null;
            Object holder = null;
            for (Method m : api.getMethods()) {
                if (m.getName().equals("markSpriteActive") && m.getParameterCount() == 1) {
                    target = m;
                    break;
                }
            }
            if (target == null) {
                off = true;
                return;
            }
            if (!java.lang.reflect.Modifier.isStatic(target.getModifiers())) {
                holder = api.getField("INSTANCE").get(null);
            }
            spriteOf = accessor;
            mark = target;
            util = holder;
        } catch (ClassNotFoundException e) {
            off = true; // Sodium is not installed
        } catch (ReflectiveOperationException | RuntimeException | LinkageError e) {
            off = true;
            Cinematic.LOGGER.debug("[Cinematic] Sodium's sprite API was not usable", e);
        }
    }
}
